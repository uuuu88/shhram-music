from math import ceil

from pyrogram.types import InlineKeyboardButton

COLUMN_SIZE = 3  # Controls the number of rows
NUM_COLUMNS = 3  # Controls the number of columns


class EqInlineKeyboardButton(InlineKeyboardButton):
    def __eq__(self, other):
        return self.text == other.text

    def __lt__(self, other):
        return self.text < other.text

    def __gt__(self, other):
        return self.text > other.text


def paginate_modules(page_n, module_dict, prefix, chat=None, closebutton=None):
    if not chat:
        modules = sorted(
            [
                EqInlineKeyboardButton(
                    x.__MODULE__,
                    callback_data="{}_module({},{})".format(
                        prefix, x.__MODULE__.lower(), page_n
                    ),
                )
                for x in module_dict.values()
            ]
        )
    else:
        modules = sorted(
            [
                EqInlineKeyboardButton(
                    x.__MODULE__,
                    callback_data="{}_module({},{},{})".format(
                        prefix, chat, x.__MODULE__.lower(), page_n
                    ),
                )
                for x in module_dict.values()
            ]
        )

    pairs = [modules[i : i + NUM_COLUMNS] for i in range(0, len(modules), NUM_COLUMNS)]

    max_num_pages = ceil(len(pairs) / COLUMN_SIZE) if len(pairs) > 0 else 1
    modulo_page = page_n % max_num_pages

    if len(pairs) > COLUMN_SIZE:
        pairs = pairs[modulo_page * COLUMN_SIZE : COLUMN_SIZE * (modulo_page + 1)]
        navigation_buttons = [
            EqInlineKeyboardButton(
                "❮",
                callback_data="{}_prev({})".format(
                    prefix,
                    modulo_page - 1 if modulo_page > 0 else max_num_pages - 1,
                ),
            ),
            EqInlineKeyboardButton(
                "❯",
                callback_data="{}_next({})".format(prefix, modulo_page + 1),
            ),
        ]

        if closebutton is None:
            navigation_buttons.insert(
                1,
                EqInlineKeyboardButton(
                    "Bᴀᴄᴋ",
                    callback_data="settingsback_helper",
                ),
            )

        pairs.append(navigation_buttons)

    return pairs
