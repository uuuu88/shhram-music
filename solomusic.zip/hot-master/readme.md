https://github.com/fps90/Hot
